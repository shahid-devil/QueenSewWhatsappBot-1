/* Codded by @Ravindu Manoj

Telegram: t.me/RavinduManoj
Facebook: https://www.facebook.com/ravindu.manoj.79

Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

Whats bot - Ravindu Manoj

*/

const QueenSew = require('../events');
const {MessageType} = require('@adiwajshing/baileys');
const Config = require('../config');
const sew = ('This command for any emergency situation about any kind of WhatsApp SPAM in Group');
const SEWQU = ('*************************************\n*👑ANTI SPAM CLEAR RIBBON👑*\n\n       👑By ' + Config.BOTNAME + '👑\n       \n\n\n\n```✨✨Do Not Go Up✨✨```\n*ඉහලට යෑමෙන් වලිකින්න.*\n            *Clear Ribbon*\n    _👑by      ' + Config.BOTNAME + '👑_\n    \n    \n\n```✨✨Do Not Go Up✨✨```\n*ඉහලට යෑමෙන් වලිකින්න.*\n            *Clear Ribbon*\n    _👑by      ' + Config.BOTNAME + '👑_\n    \n\n\n\n```✨✨Do Not Go Up✨✨```\n*ඉහලට යෑමෙන් වලිකින්න.*\n            *Clear Ribbon*\n    _👑by      ' + Config.BOTNAME + '👑_\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nᴘᴏᴡᴇʀᴅ ʙʏ ꜱᴇᴡ ǫᴜᴇᴇɴ\n*************************************')
const FINAL = "THIS IS AN ANTISAPM (anti lag),"
const MuteSew = "Trying to close group for one day,"
const MUT = ".mute 1d"
const TAG = ".tag"
const SCRIPTBYSEW = "Running Clear Reban Script....000001"
QueenSew.newcmdaddtosew({pattern: 'antispam', fromMe: true, delownsewcmd: false, desc: sew,}, (async (message, match) => {

  var msg = await message.reply('❉Safe Mode Activating....');

  await message.client.sendMessage(
    message.jid,MuteSew, MessageType.text);

    await message.client.sendMessage(
      message.jid,MUT, MessageType.text);

      await message.client.sendMessage(
        message.jid,SCRIPTBYSEW, MessageType.text);

        await message.client.sendMessage(
          message.jid,SEWQU, MessageType.text);

           await message.client.sendMessage(
             message.jid,SEWQU, MessageType.text);

              await message.client.sendMessage(
                message.jid,SEWQU, MessageType.text);

                 await message.client.sendMessage(
                   message.jid,SEWQU, MessageType.text);

                     await message.client.sendMessage(
                       message.jid,SEWQU, MessageType.text);

                         await message.client.sendMessage(
                           message.jid,SEWQU, MessageType.text);

                              await message.client.sendMessage(
                                message.jid,SEWQU, MessageType.text);

          await message.client.sendMessage(
            message.jid,SEWQU, MessageType.text);
  
         await message.client.sendMessage(
            message.jid,SEWQU, MessageType.text);
            
             await message.client.sendMessage(
                message.jid,TAG, MessageType.text);

          await message.client.sendMessage(
              message.jid,SEWQU, MessageType.text);

                await message.client.sendMessage(
                  message.jid,SEWQU, MessageType.text);

                  await message.client.sendMessage(
                    message.jid,SEWQU, MessageType.text);

                    await message.client.sendMessage(
                      message.jid,SEWQU, MessageType.text);

                      await message.client.sendMessage(
                        message.jid,SEWQU, MessageType.text);
                        
  }));
  
  
QueenSew.newcmdaddtosew({pattern: 'antispambysew', fromMe: false, delownsewcmd: false, desc: sew,}, (async (message, match) => {

  var msg = await message.reply('Preforming....');

  await message.client.sendMessage(
    message.jid,MuteSew, MessageType.text);

    await message.client.sendMessage(
      message.jid,MUT, MessageType.text);

      await message.client.sendMessage(
        message.jid,SCRIPTBYSEW, MessageType.text);

        await message.client.sendMessage(
          message.jid,SEWQU, MessageType.text);

           await message.client.sendMessage(
             message.jid,SEWQU, MessageType.text);

              await message.client.sendMessage(
                message.jid,SEWQU, MessageType.text);

                 await message.client.sendMessage(
                   message.jid,SEWQU, MessageType.text);

                     await message.client.sendMessage(
                       message.jid,SEWQU, MessageType.text);

                         await message.client.sendMessage(
                           message.jid,SEWQU, MessageType.text);

                              await message.client.sendMessage(
                                message.jid,SEWQU, MessageType.text);

          await message.client.sendMessage(
            message.jid,SEWQU, MessageType.text);
                        
              await message.client.sendMessage(
                message.jid,SEWQU, MessageType.text);

                await message.client.sendMessage(
                  message.jid,SEWQU, MessageType.text);

                  await message.client.sendMessage(
                    message.jid,SEWQU, MessageType.text);
  
         await message.client.sendMessage(
            message.jid,SEWQU, MessageType.text);
            
             await message.client.sendMessage(
                message.jid,TAG, MessageType.text);

          await message.client.sendMessage(
              message.jid,SEWQU, MessageType.text);

                await message.client.sendMessage(
                  message.jid,SEWQU, MessageType.text);

                  await message.client.sendMessage(
                    message.jid,SEWQU, MessageType.text);

                    await message.client.sendMessage(
                      message.jid,SEWQU, MessageType.text);

                      await message.client.sendMessage(
                        message.jid,SEWQU, MessageType.text);
                        
  }));
