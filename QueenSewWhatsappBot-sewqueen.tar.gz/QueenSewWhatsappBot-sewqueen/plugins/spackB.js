/* Codded by @Ravindu Manoj

Telegram: t.me/RavinduManoj
Facebook: https://www.facebook.com/ravindu.manoj.79

Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

Whats bot - Ravindu Manoj

*/

const QueenSew = require('../events');
const {MessageType} = require('@adiwajshing/baileys');

QueenSew.newcmdaddtosew({pattern: 'a robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░█████╗░\n██╔══██╗\n███████║\n██╔══██║\n██║░░██║\n╚═╝░░╚═╝');

}));

QueenSew.newcmdaddtosew({pattern: 'b robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██████╗░\n██╔══██╗\n██████╦╝\n██╔══██╗\n██████╦╝\n╚═════╝░');

}));

QueenSew.newcmdaddtosew({pattern: 'c robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░█████╗░\n██╔══██╗\n██║░░╚═╝\n██║░░██╗\n╚█████╔╝\n░╚════╝░');

}));

QueenSew.newcmdaddtosew({pattern: 'd robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██████╗░\n██╔══██╗\n██║░░██║\n██║░░██║\n██████╔╝\n╚═════╝░');

}));

QueenSew.newcmdaddtosew({pattern: 'e robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('███████╗\n██╔════╝\n█████╗░░\n██╔══╝░░\n███████╗\n╚══════╝');

}));

QueenSew.newcmdaddtosew({pattern: 'f robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('███████╗\n██╔════╝\n█████╗░░\n██╔══╝░░\n██║░░░░░\n╚═╝░░░░░');

}));

QueenSew.newcmdaddtosew({pattern: 'g robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░██████╗░\n██╔════╝░\n██║░░██╗░\n██║░░╚██╗\n╚██████╔╝\n░╚═════╝░');

}));

QueenSew.newcmdaddtosew({pattern: 'h robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██╗░░██╗\n██║░░██║\n███████║\n██╔══██║\n██║░░██║\n╚═╝░░╚═╝');

}));

QueenSew.newcmdaddtosew({pattern: 'ı robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██╗\n██║\n██║\n██║\n██║\n╚═╝');

}));

QueenSew.newcmdaddtosew({pattern: 'i robo', fromMe: false, dontAdCommandList: true,}, (async (message, match) => {

    await message.sendMessage('██╗\n╚═╝\n██╗\n██║\n██║\n██║\n██║\n╚═╝');

}));

QueenSew.newcmdaddtosew({pattern: 'j robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░░░░░██╗\n░░░░░██║\n░░░░░██║\n██╗░░██║\n╚█████╔╝\n░╚════╝░');

}));

QueenSew.newcmdaddtosew({pattern: 'k robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██╗░░██╗\n██║░██╔╝\n█████═╝░\n██╔═██╗░\n██║░╚██╗\n╚═╝░░╚═╝');

}));

QueenSew.newcmdaddtosew({pattern: 'l robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██╗░░░░░\n██║░░░░░\n██║░░░░░\n██║░░░░░\n███████╗\n╚══════╝');

}));

QueenSew.newcmdaddtosew({pattern: 'm robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('███╗░░░███╗\n████╗░████║\n██╔████╔██║\n██║╚██╔╝██║\n██║░╚═╝░██║\n╚═╝░░░░░╚═╝');

}));

QueenSew.newcmdaddtosew({pattern: 'n robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('███╗░░██╗\n████╗░██║\n██╔██╗██║\n██║╚████║\n██║░╚███║\n╚═╝░░╚══╝');

}));

QueenSew.newcmdaddtosew({pattern: 'o robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░█████╗░\n██╔══██╗\n██║░░██║\n██║░░██║\n╚█████╔╝\n░╚════╝░');

}));

QueenSew.newcmdaddtosew({pattern: 'p robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██████╗░\n██╔══██╗\n██████╔╝\n██╔═══╝░\n██║░░░░░\n╚═╝░░░░░');

}));

QueenSew.newcmdaddtosew({pattern: 'q robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░██████╗░\n██╔═══██╗\n██║██╗██║\n╚██████╔╝\n░╚═██╔═╝░\n░░░╚═╝░░░');

}));

QueenSew.newcmdaddtosew({pattern: 'r robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██████╗░\n██╔══██╗\n██████╔╝\n██╔══██╗\n██║░░██║\n╚═╝░░╚═╝');

}));

QueenSew.newcmdaddtosew({pattern: 's robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░██████╗\n██╔════╝\n╚█████╗░\n░╚═══██╗\n██████╔╝\n╚═════╝░');

}));

QueenSew.newcmdaddtosew({pattern: 't robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('████████╗\n╚══██╔══╝\n░░░██║░░░\n░░░██║░░░\n░░░██║░░░\n░░░╚═╝░░░');

}));

QueenSew.newcmdaddtosew({pattern: 'u robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██╗░░░██╗\n██║░░░██║\n██║░░░██║\n██║░░░██║\n╚██████╔╝\n░╚═════╝░');

}));

QueenSew.newcmdaddtosew({pattern: 'w robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░██╗░░░░░░░██╗\n░██║░░██╗░░██║\n░╚██╗████╗██╔╝\n░░████╔═████║░\n░░╚██╔╝░╚██╔╝░\n░░░╚═╝░░░╚═╝░░');

}));

QueenSew.newcmdaddtosew({pattern: 'v robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██╗░░░██╗\n██║░░░██║\n╚██╗░██╔╝\n░╚████╔╝░\n░░╚██╔╝░░\n░░░╚═╝░░░');

}));

QueenSew.newcmdaddtosew({pattern: 'x robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██╗░░██╗\n╚██╗██╔╝\n░╚███╔╝░\n░██╔██╗░\n██╔╝╚██╗\n╚═╝░░╚═╝');

}));

QueenSew.newcmdaddtosew({pattern: 'y robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██╗░░░██╗\n╚██╗░██╔╝\n░╚████╔╝░\n░░╚██╔╝░░\n░░░██║░░░\n░░░╚═╝░░░');

}));

QueenSew.newcmdaddtosew({pattern: 'z robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('███████╗\n╚════██║\n░░███╔═╝\n██╔══╝░░\n███████╗\n╚══════╝');

}));

QueenSew.newcmdaddtosew({pattern: '1 robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░░███╗░░\n░████║░░\n██╔██║░░\n╚═╝██║░░\n███████╗\n╚══════╝');

}));

QueenSew.newcmdaddtosew({pattern: '2 robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██████╗░\n╚════██╗\n░░███╔═╝\n██╔══╝░░\n███████╗\n╚══════╝');

}));

QueenSew.newcmdaddtosew({pattern: '3 robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('██████╗░\n╚════██╗\n░█████╔╝\n░╚═══██╗\n██████╔╝\n╚═════╝░');

}));

QueenSew.newcmdaddtosew({pattern: '4 robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░░██╗██╗\n░██╔╝██║\n██╔╝░██║\n███████║\n╚════██║\n░░░░░╚═╝');

}));

QueenSew.newcmdaddtosew({pattern: '5 robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('███████╗\n██╔════╝\n██████╗░\n╚════██╗\n██████╔╝\n╚═════╝░');

}));

QueenSew.newcmdaddtosew({pattern: '6 robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░█████╗░\n██╔═══╝░\n██████╗░\n██╔══██╗\n╚█████╔╝\n░╚════╝░');

}));

QueenSew.newcmdaddtosew({pattern: '7 robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('███████╗\n╚════██║\n░░░░██╔╝\n░░░██╔╝░\n░░██╔╝░░\n░░╚═╝░░░');

}));

QueenSew.newcmdaddtosew({pattern: '8 robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░█████╗░\n██╔══██╗\n╚█████╔╝\n██╔══██╗\n╚█████╔╝\n░╚════╝░');

}));

QueenSew.newcmdaddtosew({pattern: '9 robo', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage('░█████╗░\n██╔══██╗\n╚██████║\n░╚═══██║\n░█████╔╝\n░╚════╝░');

}));

QueenSew.newcmdaddtosew({pattern: 'cry', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    var r_text = new Array ();

r_text[0] = " *๐·°(৹˃̵﹏˂̵৹)°·๐* ";
r_text[1] = " *‧º·(˚ ˃̣̣̥⌓˂̣̣̥ )‧º·˚* ";
r_text[2] = " *(つ﹏<)･ﾟ｡* ";
r_text[3] = " *｡ﾟ･（>﹏<）･ﾟ｡* ";
r_text[4] = " *๐·°(৹˃̵﹏˂̵৹)°·๐* ";
r_text[5] = " *.·´¯`(>▂<)´¯`·.* ";
r_text[6] = " *｡･ﾟﾟ･(>д<)･ﾟﾟ･｡* ";
r_text[7] = " *(ToT)* ";
r_text[8] = " *(┳Д┳)* ";
r_text[9] = " *(ಥ﹏ಥ)* ";
r_text[10] = " *（；へ：）* ";
r_text[11] = " *ಥʖ̯ಥ* ";
r_text[12] = " *ಥ ͜ʖಥ* ";
r_text[13] = " *☭ ͜ʖ ☭* ";
r_text[14] = " *ཀ ʖ̯ ཀ* ";
r_text[15] = " *(;﹏;)* ";
r_text[16] = " *（πーπ）* ";
r_text[17] = " *(⋟﹏⋞)* ";
r_text[18] = " *（>﹏<）* ";
r_text[19] = " *(つ﹏⊂)* ";
r_text[20] = " *༼☯﹏☯༽* ";
r_text[21] = " *(ノ﹏ヽ)* ";
r_text[22] = " *(╥_╥)* ";
r_text[23] = " *(T⌓T)* ";
r_text[24] = " *(༎ຶ⌑༎ຶ)* ";
r_text[25] = " *(☍﹏⁰)｡* ";
r_text[26] = " *(இ﹏இ`｡)* ";
r_text[27] = " *༼ ༎ຶ ෴ ༎ຶ༽* ";
r_text[28] = " *ᕕ( ཀ ʖ̯ ཀ)ᕗ* ";
r_text[29] = " *( ɵ̥̥ ˑ̫ ɵ̥̥)* ";
r_text[30] = " *(个_个)* ";
r_text[31] = " *( ͒˃̩̩⌂˂̩̩ ͒)* ";
r_text[32] = " *╥﹏╥* ";
r_text[33] = " *༼ಢ_ಢ༽* ";

var i = Math.floor(34*Math.random())

await message.sendMessage(`${r_text[i]}`);

}));

QueenSew.newcmdaddtosew({pattern: 'run', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    var r_text = new Array ();

r_text[0] = " *ᕕ( ᐛ )ᕗ* ";
r_text[1] = " *┌( ಠ_ಠ)┘* ";
r_text[2] = " *ᕕ(╯°□°)ᕗ* ";
r_text[3] = " *ᕕ༼✪ل͜✪༽ᕗ* ";
r_text[4] = " *┌（・Σ・）┘≡З* ";
r_text[5] = " *ᕕ( ಠ‿ಠ)ᕗ* ";
r_text[6] = " *ᕕ(◉Д◉ )ᕗ* ";
r_text[7] = " *ᕕ( ཀ ʖ̯ ཀ)ᕗ* ";
r_text[8] = " *ε＝( ✧≖ ͜ʖ≖)* ";
r_text[9] = " *ღ(▀̿Ĺ̯▀̿ ̿ღ)ミ* ";
r_text[10] = " *٩(▀̿Ĺ̯▀̿ ̿٩)三* ";
r_text[11] = " *ᕕ( ͡° ͜ʖ ͡°)ᕗ* ";
r_text[12] = " *ε＝（ﾉ ͡° ͜ʖ ͡°)ﾉ* ";
r_text[13] = " *─=≡Σᕕ( ͡° ͜ʖ ͡°)ᕗ* ";
r_text[14] = " *－－＝Ξ/╲/( ͡° ͡° ͜ʖ ͡° ͡°)/\╱\* ";
r_text[15] = " *٩(•౪•٩)三* ";
r_text[16] = " *｡｡゛(ﾉ><)ﾉ* ";
r_text[17] = " *ε＝（ﾉﾟдﾟ）ﾉ* ";
r_text[18] = " *┏( ゜)ਊ゜)┛* ";
r_text[19] = " *｢(◔ω◔「)三* ";

var i = Math.floor(20*Math.random())

await message.sendMessage(`${r_text[i]}`);

}));

QueenSew.newcmdaddtosew({pattern: 'slap ?(.*)', fromMe: false}, (async (message, match) => {

    if (message.reply_message === false) {

        return await message.sendMessage('*Give me someone to beat!*');

    } else

        await message.client.sendMessage(message.jid, '@' + message.reply_message.jid.split('@')[0] + ' *Im burned you now!* ', MessageType.text, {
            quotedMessage: message.reply_message.data, contextInfo: {mentionedJid: [message.reply_message.jid.replace('c.us', 's.whatsapp.net')]}

    });

    await new Promise(r => setTimeout(r, 1000));

    var r_text = new Array ();

r_text[0] = " * Sew, shovels the mouth of your chosen one!* ";
r_text[1] = " * Sew, first tied your chosen one, then poured gasoline and lit!* ";
r_text[2] = " * Sew, threw your chosen one into electric water!* ";
r_text[3] = " * Sew, squeezes and beats your chosen one!* ";
r_text[4] = " * Sew, tied concrete to the feet of your chosen one, then he tied his hands and feets and threw it into the pool with piranha-filled!* ";
r_text[5] = " * Sew, slaps your chosen one until he/she faints* ";
r_text[6] = " * Sew, tapes the mouth of your chosen one and then beats him with a crowbar!* ";
r_text[7] = " * Sew, hits the head of your chosen one with a stone and knocks out then beating until consciousness!* ";
r_text[9] = " * Sew, hangs her from the celling og your chosen one and does boxing training!* ";
r_text[10] = " * Sew, beats your chosen one with plastic pipes!* ";
r_text[11] = " * Sew, punching the kidneys of your chosen one* ";
r_text[12] = " * Sew stops the heart of the one you chose, then with everybody in this group beats until his heart works again!* ";
r_text[13] = " * Sew buries your chosen one while his alive!* ";

var i = Math.floor(14*Math.random())

await message.sendMessage(`${r_text[i]}`);

}));


QueenSew.newcmdaddtosew({pattern: 'spack', fromMe: false}, (async (message, match) => {

    await message.sendMessage('*Codded by t.me/RavinduManoj*\n💻Usage: *. robo*\nℹ️Desc:Translate any word to Robo text.\n⌨️Ex: *.a robo*, *.e robo*, *2 robo* etc.\n\n💻Usage: *.cry*\nℹ️Desc:It sends crying emoji texs.\n\n💻Usage: *.run*\nℹ️Desc:It sends run emojis texts.\n\n💻Usage: *.slap <reply>*\nℹ️Desc: sew, beats whoever you replied messages.\n\n');

}));