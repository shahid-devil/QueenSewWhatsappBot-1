const QueenSew = require('../events');
const {MessageType} = require('@adiwajshing/baileys');

// Config Checker

const ch = require('../config');

// Languages
const END = "Thats a plugin with enjoyable tools together inside. (Meme Pack V3)"
const TRD = "Birbirinden farklı değişik ve eğlenceli araçların bir arada bulunduğu bir plugindir (2.versiyondur yani devamıdır)"
const HID = "यह एक प्लगइन के साथ सुखद उपकरण अंदर है। (Meme Pack V3)"


    if (ch.WORKTYPE === 'private') {
   
        QueenSew.newcmdaddtosew({pattern: 'npack', fromMe: true, desc: END}, (async (message, match) => {

            await message.sendMessage("_Thats a plugin with enjoyable tools together inside._\n👑Usage: *.n7*\n💠Desc: *Celebrate a birthday.*\n\n👑Usage: *.n8*\n💠Desc: *How about a little shot?*\n\n👑Usage: *.n9*\n💠Desc: *A different way to say I love you*\n\n👑Usage: *.n1*\n💠Desc: *How about landing in a helicopter and revealing your love?*\n\n👑Usage: *.n2*\n💠Desc: *Send someone a heart, let's see what you got.*\n\n👑Usage: *.n3*\n💠Desc: *How about sending a tank?*\n\n👑Usage: *.n4*\n💠Desc: *For those who are burning with the love of GS*\n\n👑Usage: *.n5*\n💠Desc: *How about sending dislike?*\n\n👑Usage: *.n6*\n💠Desc: *How about sending a cat to cheer up the chat?*\n\nCodded by by *t.me/RavinduManoj*");

        }));

        QueenSew.newcmdaddtosew({pattern: 'm7', fromMe: true, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("\n♪ღ♪*•.¸¸.•*¨¨*•.♪ღ♪*•.¸¸.•*¨¨*•.♪ღ♪\n░H░A░P░P░Y░♪░B░I░R░T░H░D░A░Y░\n♪ღ♪*•.¸¸.•*¨¨*•.♪ღ♪*•.¸¸.•*¨¨*•.♪ღ♪");

        }));

        QueenSew.newcmdaddtosew({pattern: 'm8', fromMe: true, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("\n_/﹋\_\n(҂`_´)\n<,︻╦╤─ ҉ - -\n_/﹋\_");

        }));

        QueenSew.newcmdaddtosew({pattern: 'm9', fromMe: true, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("╔══╗╔╗ ♡ ♡ ♡\n╚╗╔╝║║╔═╦╦╦╔╗\n╔╝╚╗║╚╣║║║║╔╣\n╚══╝╚═╩═╩═╩═╝\nஜ۞ஜ YOU ஜ۞ஜ");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n1', fromMe: true, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage(" ▬▬▬.◙.▬▬▬\n ═▂▄▄▓▄▄▂\n◢◤ █▀▀████▄▄▄▄◢◤\n█▄▂█ █▄███▀▀▀▀▀▀▀╬\n◥█████◤\n══╩══╩═\n ╬═╬\n ╬═╬\n ╬═╬\n ╬═╬\n ╬═╬\n ╬═╬ ☻/\n ╬═╬/▌\n ╬═╬/");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n2', fromMe: true, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("(っ◔◡◔っ) ❤");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n3', fromMe: true, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("  ░░░░░░███████ ]▄▄▄▄▄▄▄▄          \n▂▄▅█████████▅▄▃▂   \nIl███████████████████].   ◥⊙▲⊙▲⊙▲⊙▲⊙▲⊙▲⊙◤..\n");
  
        }));

        QueenSew.newcmdaddtosew({pattern: 'n4', fromMe: true, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑\n🌑🌑🌒🌘🌑🌑🌑🌒🌘🌑🌑\n🌑🌔🌕🌕🌕🌑🌕🌕🌕🌖🌑\n🌑🌕🌕🌕🌕🌕🌕🌕🌕🌕🌑\n🌑🌔🌕🌕🌕🌕🌕🌕🌕🌖🌑\n🌑🌒🌕🌕🌕🌕🌕🌕🌕🌘🌑\n🌑🌑🌒🌕🌕🌕🌕🌕🌘🌑🌑\n🌑🌑🌒🌕🌕🌕🌕🌕🌘🌑🌑\n🌑🌑🌑🌒🌕🌕🌕🌘🌑🌑🌑\n🌑🌑🌑🌑🌒🌕🌘🌑🌑🌑🌑\n🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑\n🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑\n🌑🌑🌒🌘🌑🌑🌑🌒🌘🌑🌑\n🌑🌒❤️❤️🌘🌑🌒❤️❤️🌘🌑\n🌑🌔❤️❤️🌕🌑❤️❤️❤️🌖🌑\n🌑❤️❤️❤️❤️❤️❤️❤️❤️❤️🌑\n🌑🌔❤️❤️❤️❤️❤️❤️❤️🌖🌑\n🌑🌒❤️❤️❤️❤️❤️❤️❤️🌘🌑\n🌑🌑🌒❤️❤️❤️❤️❤️🌘🌑🌑\n🌑🌑🌑🌒❤️❤️❤️🌘🌑🌑🌑\n🌑🌑🌑🌑🌒🌕🌘🌑🌑🌑🌑\n🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n5', fromMe: true, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("███████▄▄███████████▄\n▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n▓▓▓▓▓▓███░░░░░░░░░░░░█\n██████▀░░█░░░░██████▀\n░░░░░░░░░█░░░░█\n░░░░░░░░░░█░░░█\n░░░░░░░░░░░█░░█\n░░░░░░░░░░░█░░█\n░░░░░░░░░░░░▀▀");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n6', fromMe: true, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("──────▄▀▄─────▄▀▄\n─────▄█░░▀▀▀▀▀░░█▄\n─▄▄──█░░░░░░░░░░░█──▄▄\n█▄▄█─█░░▀░░┬░░▀░░█─█▄▄█");

        }));

    }
    else if (ch.WORKTYPE === 'public') {
   
        QueenSew.newcmdaddtosew({pattern: 'npack', fromMe: false, desc: END}, (async (message, match) => {

            await message.sendMessage("_Thats a plugin with enjoyable tools together inside._\n👑Usage: *.n7*\n💠Desc: *Celebrate a birthday.*\n\n👑Usage: *.n8*\n💠Desc: *How about a little shot?*\n\n👑Usage: *.n9*\n💠Desc: *A different way to say I love you*\n\n👑Usage: *.n1*\n💠Desc: *How about landing in a helicopter and revealing your love?*\n\n👑Usage: *.n2*\n💠Desc: *Send someone a heart, let's see what you got.*\n\n👑Usage: *.n3*\n💠Desc: *How about sending a tank?*\n\n👑Usage: *.n4*\n💠Desc: *For those who are burning with the love of GS*\n\n👑Usage: *.n5*\n💠Desc: *How about sending dislike?*\n\n👑Usage: *.n6*\n💠Desc: *How about sending a cat to cheer up the chat?*\n\nCodded by by *t.me/RavinduManoj*");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n7', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("\n♪ღ♪*•.¸¸.•*¨¨*•.♪ღ♪*•.¸¸.•*¨¨*•.♪ღ♪\n░H░A░P░P░Y░♪░B░I░R░T░H░D░A░Y░\n♪ღ♪*•.¸¸.•*¨¨*•.♪ღ♪*•.¸¸.•*¨¨*•.♪ღ♪");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n8', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("\n_/﹋\_\n(҂`_´)\n<,︻╦╤─ ҉ - -\n_/﹋\_");

        }));

        QueenSew.newcmdaddtosew({pattern: 'm9', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("╔══╗╔╗ ♡ ♡ ♡\n╚╗╔╝║║╔═╦╦╦╔╗\n╔╝╚╗║╚╣║║║║╔╣\n╚══╝╚═╩═╩═╩═╝\n❤۞❤ YOU ❤۞❤");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n1', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage(" ▬▬▬.◙.▬▬▬\n ═▂▄▄▓▄▄▂\n◢◤ █▀▀████▄▄▄▄◢◤\n█▄▂█ █▄███▀▀▀▀▀▀▀╬\n◥█████◤\n══╩══╩═\n ╬═╬\n ╬═╬\n ╬═╬\n ╬═╬\n ╬═╬\n ╬═╬ ☻/\n ╬═╬/▌\n ╬═╬/");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n2', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("(っ◔◡◔っ) ❤");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n3', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("  ░░░░░░███████ ]▄▄▄▄▄▄▄▄          \n▂▄▅█████████▅▄▃▂   \nIl███████████████████].   ◥⊙▲⊙▲⊙▲⊙▲⊙▲⊙▲⊙◤..\n");
  
        }));

        QueenSew.newcmdaddtosew({pattern: 'n4', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑\n🌑🌑🌒🌘🌑🌑🌑🌒🌘🌑🌑\n🌑🌔🌕🌕🌕🌑🌕🌕🌕🌖🌑\n🌑🌕🌕🌕🌕🌕🌕🌕🌕🌕🌑\n🌑🌔🌕🌕🌕🌕🌕🌕🌕🌖🌑\n🌑🌒🌕🌕🌕🌕🌕🌕🌕🌘🌑\n🌑🌑🌒🌕🌕🌕🌕🌕🌘🌑🌑\n🌑🌑🌒🌕🌕🌕🌕🌕🌘🌑🌑\n🌑🌑🌑🌒🌕🌕🌕🌘🌑🌑🌑\n🌑🌑🌑🌑🌒🌕🌘🌑🌑🌑🌑\n🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑\n🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑\n🌑🌑🌒🌘🌑🌑🌑🌒🌘🌑🌑\n🌑🌒❤️❤️🌘🌑🌒❤️❤️🌘🌑\n🌑🌔❤️❤️🌕🌑❤️❤️❤️🌖🌑\n🌑❤️❤️❤️❤️❤️❤️❤️❤️❤️🌑\n🌑🌔❤️❤️❤️❤️❤️❤️❤️🌖🌑\n🌑🌒❤️❤️❤️❤️❤️❤️❤️🌘🌑\n🌑🌑🌒❤️❤️❤️❤️❤️🌘🌑🌑\n🌑🌑🌑🌒❤️❤️❤️🌘🌑🌑🌑\n🌑🌑🌑🌑🌒🌕🌘🌑🌑🌑🌑\n🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑🌑");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n5', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("███████▄▄███████████▄\n▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n▓▓▓▓▓▓███░░░░░░░░░░░░█\n██████▀░░█░░░░██████▀\n░░░░░░░░░█░░░░█\n░░░░░░░░░░█░░░█\n░░░░░░░░░░░█░░█\n░░░░░░░░░░░█░░█\n░░░░░░░░░░░░▀▀");

        }));

        QueenSew.newcmdaddtosew({pattern: 'n6', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

            await message.sendMessage("──────▄▀▄─────▄▀▄\n─────▄█░░▀▀▀▀▀░░█▄\n─▄▄──█░░░░░░░░░░░█──▄▄\n█▄▄█─█░░▀░░┬░░▀░░█─█▄▄█");

        }));

    }
